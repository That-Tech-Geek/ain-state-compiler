document.addEventListener('DOMContentLoaded', () => {
    // Tab switching
    const navItems = document.querySelectorAll('.nav-item');
    const tabPanes = document.querySelectorAll('.tab-pane');

    navItems.forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const target = e.target.getAttribute('data-tab');
            
            navItems.forEach(nav => nav.classList.remove('active'));
            e.target.classList.add('active');
            
            tabPanes.forEach(pane => pane.classList.remove('active'));
            document.getElementById(`tab-${target}`).classList.add('active');
        });
    });

    // API Base URL
    const API_BASE = window.location.origin + '/api';

    // Toast notification
    const showToast = (message, isError = false) => {
        const toast = document.getElementById('toast');
        toast.textContent = message;
        toast.style.background = isError ? 'var(--alert-red)' : 'var(--success-green)';
        toast.classList.add('show');
        setTimeout(() => toast.classList.remove('show'), 3000);
    };

    // Health Chart Initialization
    const ctx = document.getElementById('healthChart').getContext('2d');
    const healthChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Stable States', 'Conflicts'],
            datasets: [{
                data: [100, 0],
                backgroundColor: ['#10b981', '#ef4444'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: 'bottom', labels: { color: '#94a3b8' } }
            }
        }
    });

    // Fetch Status
    const fetchStatus = async () => {
        try {
            const res = await fetch(`${API_BASE}/status`);
            if (!res.ok) throw new Error('Status fetch failed');
            const data = await res.json();
            
            document.getElementById('stat-slack').textContent = data.slack.toLocaleString();
            document.getElementById('stat-jira').textContent = data.jira.toLocaleString();
            document.getElementById('stat-emails').textContent = data.emails.toLocaleString();
            document.getElementById('stat-conflicts').textContent = data.conflicts;
            document.getElementById('nav-conflict-badge').textContent = data.conflicts;
            
            // Format date if possible
            let syncTime = data.last_ingest;
            if (syncTime !== "Never") {
                try { syncTime = new Date(syncTime).toLocaleString(); } catch (e) {}
            }
            document.getElementById('last-sync-time').textContent = `Last Sync: ${syncTime}`;

            // Update chart
            const total = data.slack + data.jira + data.emails;
            // Fake ratio for visual if no events
            if (total > 0) {
                healthChart.data.datasets[0].data = [100 - (data.conflicts*5), data.conflicts*5];
                healthChart.update();
            }

        } catch (error) {
            console.error(error);
        }
    };

    // Fetch Raw Feeds (for event stream)
    const fetchFeeds = async () => {
        try {
            const res = await fetch(`${API_BASE}/raw-feeds`);
            if (!res.ok) throw new Error('Feeds fetch failed');
            const data = await res.json();
            
            const stream = document.getElementById('event-stream');
            stream.innerHTML = '';
            
            // Interleave events (simulate live stream)
            const allEvents = [];
            (data.slack || []).slice(0, 20).forEach(e => allEvents.push({src: 'slack', text: e.text || 'Message in ' + e.channel, ts: e.timestamp || 0}));
            (data.jira || []).slice(0, 20).forEach(e => allEvents.push({src: 'jira', text: `[${e.id}] ${e.title} - ${e.status}`, ts: e.updated_at || e.timestamp || 0}));
            (data.emails || []).slice(0, 20).forEach(e => allEvents.push({src: 'email', text: `Subj: ${e.subject}`, ts: e.timestamp || 0}));
            
            allEvents.sort((a,b) => (b.ts - a.ts) || (Math.random() - 0.5));
            
            allEvents.slice(0, 50).forEach(ev => {
                const div = document.createElement('div');
                div.className = 'feed-item';
                div.innerHTML = `
                    <div class="feed-source src-${ev.src}">${ev.src}</div>
                    <div class="feed-content">${ev.text.substring(0, 150)}${ev.text.length > 150 ? '...' : ''}</div>
                `;
                stream.appendChild(div);
            });

            if(allEvents.length === 0) {
                stream.innerHTML = '<div class="loader">No events found in database.</div>';
            }

        } catch (error) {
            console.error(error);
        }
    };

    // Fetch State (Conflicts)
    const fetchState = async () => {
        try {
            const res = await fetch(`${API_BASE}/state`);
            if (!res.ok) throw new Error('State fetch failed');
            const data = await res.json();
            
            const container = document.getElementById('conflicts-container');
            container.innerHTML = '';
            
            const conflicts = data.operational_execution_graph?.conflict_disputes || [];
            
            if (conflicts.length === 0) {
                container.innerHTML = '<div class="loader" style="color: var(--success-green)">No active conflicts detected. System is in harmony.</div>';
                return;
            }

            conflicts.forEach(c => {
                const div = document.createElement('div');
                div.className = `conflict-card ${c.severity}`;
                
                let evHtml = '';
                (c.evidence || []).forEach(e => {
                    evHtml += `<div class="conflict-evidence">• ${e}</div>`;
                });

                div.innerHTML = `
                    <div class="conflict-header">
                        <span class="conflict-id">${c.id}</span>
                        <span class="badge" style="background: ${c.severity === 'CRITICAL' ? 'var(--alert-red)' : 'var(--warning-yellow)'}">${c.severity}</span>
                    </div>
                    <div class="conflict-title">${c.title}</div>
                    <div class="conflict-summary">${c.summary}</div>
                    <div class="conflict-evidence-list">
                        ${evHtml}
                    </div>
                    <div class="conflict-action">
                        <strong>Action Required:</strong> ${c.resolution || c.resolution_action || 'Review required'}
                    </div>
                `;
                container.appendChild(div);
            });

        } catch (error) {
            console.error(error);
        }
    };

    // Chat functionality
    const chatInput = document.getElementById('chat-input');
    const chatSend = document.getElementById('chat-send');
    const chatHistory = document.getElementById('chat-history');

    const appendMessage = (text, isUser, sourceNode = null) => {
        const div = document.createElement('div');
        div.className = `chat-message ${isUser ? 'user-message' : 'ai-message'}`;
        
        let sourceHtml = sourceNode && sourceNode !== 'None' ? `<div class="source-tag">Source: ${sourceNode}</div>` : '';
        
        div.innerHTML = `
            <div class="avatar">${isUser ? 'You' : 'AIN'}</div>
            <div class="message-content">
                ${text.replace(/\\n/g, '<br>')}
                ${sourceHtml}
            </div>
        `;
        chatHistory.appendChild(div);
        chatHistory.scrollTop = chatHistory.scrollHeight;
    };

    const handleQuery = async () => {
        const text = chatInput.value.trim();
        if (!text) return;

        appendMessage(text, true);
        chatInput.value = '';
        chatInput.disabled = true;
        chatSend.disabled = true;

        // Add thinking loader
        const thinkingId = 'think-' + Date.now();
        const thinkDiv = document.createElement('div');
        thinkDiv.id = thinkingId;
        thinkDiv.className = 'chat-message ai-message';
        thinkDiv.innerHTML = `<div class="avatar">AIN</div><div class="message-content" style="opacity: 0.7">Synthesizing context...</div>`;
        chatHistory.appendChild(thinkDiv);

        try {
            const res = await fetch(`${API_BASE}/query?text=${encodeURIComponent(text)}`);
            const data = await res.json();
            
            document.getElementById(thinkingId).remove();
            
            if (data.error) {
                appendMessage("Error: " + data.error, false);
            } else {
                appendMessage(data.answer, false, data.node);
            }
        } catch (error) {
            document.getElementById(thinkingId).remove();
            appendMessage("Failed to connect to the Company Brain.", false);
        } finally {
            chatInput.disabled = false;
            chatSend.disabled = false;
            chatInput.focus();
        }
    };

    chatSend.addEventListener('click', handleQuery);
    chatInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') handleQuery();
    });

    // Compile button
    document.getElementById('compile-btn').addEventListener('click', async () => {
        const btn = document.getElementById('compile-btn');
        btn.textContent = 'Compiling...';
        btn.disabled = true;

        try {
            const res = await fetch(`${API_BASE}/compile`);
            if (!res.ok) throw new Error();
            showToast('State compiled successfully!');
            await Promise.all([fetchStatus(), fetchState()]);
        } catch (e) {
            showToast('Compilation failed.', true);
        } finally {
            btn.textContent = 'Sync & Compile';
            btn.disabled = false;
        }
    });

    // Initial load
    fetchStatus();
    fetchFeeds();
    fetchState();
    
    // Poll status every 30s
    setInterval(fetchStatus, 30000);
});
