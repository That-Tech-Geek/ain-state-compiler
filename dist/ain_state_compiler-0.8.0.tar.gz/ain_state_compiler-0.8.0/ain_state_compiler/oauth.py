import http.server
import urllib.parse
import webbrowser
import threading
import json
import urllib.request
import urllib.error

class OAuthCallbackHandler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        query = urllib.parse.urlparse(self.path).query
        params = urllib.parse.parse_qs(query)
        if "code" in params:
            self.server.oauth_code = params["code"][0]
            self.send_response(200)
            self.send_header("Content-type", "text/html")
            self.end_headers()
            self.wfile.write(b"<html><body><h1>Authentication Successful!</h1><p>You can close this window and return to the terminal.</p></body></html>")
        else:
            self.send_response(400)
            self.send_header("Content-type", "text/html")
            self.end_headers()
            self.wfile.write(b"<html><body><h1>Authentication Failed.</h1><p>No code provided.</p></body></html>")
            
    def log_message(self, format, *args):
        pass # Suppress logging

def run_atlassian_oauth(client_id: str, client_secret: str):
    """
    Spins up a local server, opens the browser for Atlassian OAuth, and captures the token.
    Returns (access_token, refresh_token, cloud_id)
    """
    # Start local server
    port = 8080
    server_address = ('localhost', port)
    httpd = http.server.HTTPServer(server_address, OAuthCallbackHandler)
    httpd.oauth_code = None

    # Construct Authorization URL
    auth_url = f"https://auth.atlassian.com/authorize?audience=api.atlassian.com&client_id={client_id}&scope=read%3Ajira-work%20read%3Ajira-user&redirect_uri=http%3A%2F%2Flocalhost%3A8080%2Fcallback&state=localauth&response_type=code&prompt=consent"
    
    print(f"\n[*] Opening browser to authenticate with Atlassian: {auth_url}")
    webbrowser.open(auth_url)

    print("[*] Waiting for authentication...")
    while httpd.oauth_code is None:
        httpd.handle_request()
        
    code = httpd.oauth_code
    print("[+] Received authorization code. Exchanging for access token...")

    # Exchange code for token
    token_url = "https://auth.atlassian.com/oauth/token"
    payload = json.dumps({
        "grant_type": "authorization_code",
        "client_id": client_id,
        "client_secret": client_secret,
        "code": code,
        "redirect_uri": "http://localhost:8080/callback"
    }).encode("utf-8")
    
    req = urllib.request.Request(token_url, data=payload, headers={"Content-Type": "application/json"})
    
    try:
        with urllib.request.urlopen(req) as response:
            token_data = json.loads(response.read().decode())
            access_token = token_data["access_token"]
            refresh_token = token_data.get("refresh_token", "")
            
            # Fetch Cloud ID (accessible-resources)
            req2 = urllib.request.Request("https://api.atlassian.com/oauth/token/accessible-resources", headers={"Authorization": f"Bearer {access_token}"})
            with urllib.request.urlopen(req2) as resp2:
                resources = json.loads(resp2.read().decode())
                if not resources:
                    raise Exception("No accessible Atlassian resources found for this user.")
                cloud_id = resources[0]["id"]
                print(f"[+] Successfully authenticated and retrieved Cloud ID: {cloud_id}")
                return access_token, refresh_token, cloud_id
    except urllib.error.HTTPError as e:
        print(f"[!] OAuth Exchange failed: HTTP {e.code} {e.read().decode()}")
        raise
    except Exception as e:
        print(f"[!] OAuth error: {e}")
        raise

def run_google_oauth(client_id: str, client_secret: str):
    """
    Spins up a local server, opens the browser for Google OAuth, and captures the token.
    Returns (access_token, refresh_token)
    """
    # Start local server
    port = 8080
    server_address = ('localhost', port)
    httpd = http.server.HTTPServer(server_address, OAuthCallbackHandler)
    httpd.oauth_code = None

    # Construct Authorization URL
    auth_url = (
        "https://accounts.google.com/o/oauth2/v2/auth?"
        "response_type=code&"
        f"client_id={urllib.parse.quote(client_id)}&"
        "redirect_uri=http://localhost:8080/callback&"
        "scope=https://mail.google.com/&"
        "access_type=offline&"
        "prompt=consent"
    )
    
    print(f"\n[*] Opening browser to authenticate with Google: {auth_url}")
    webbrowser.open(auth_url)

    print("[*] Waiting for authentication...")
    while httpd.oauth_code is None:
        httpd.handle_request()
        
    code = httpd.oauth_code
    print("[+] Received authorization code. Exchanging for Google access token...")

    # Exchange code for token
    token_url = "https://oauth2.googleapis.com/token"
    payload = urllib.parse.urlencode({
        "grant_type": "authorization_code",
        "client_id": client_id,
        "client_secret": client_secret,
        "code": code,
        "redirect_uri": "http://localhost:8080/callback"
    }).encode("utf-8")
    
    req = urllib.request.Request(token_url, data=payload)
    
    try:
        with urllib.request.urlopen(req) as response:
            token_data = json.loads(response.read().decode())
            access_token = token_data["access_token"]
            refresh_token = token_data.get("refresh_token", "")
            print(f"[+] Successfully authenticated with Google.")
            return access_token, refresh_token
    except urllib.error.HTTPError as e:
        print(f"[!] Google OAuth Exchange failed: HTTP {e.code} {e.read().decode()}")
        raise
    except Exception as e:
        print(f"[!] Google OAuth error: {e}")
        raise
