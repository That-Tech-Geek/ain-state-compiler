"""
Query Module
On-demand contextual querying of the compiled Company Brain.

Flow:
  1. Offline keyword-based context selection (no LLM dependency)
  2. Read the matching local IMM markdown / OEG YAML
  3. Submit to local Ollama (gemma3:1b) for inference
  4. If Ollama is offline, fall back to deterministic state resolver

Zero-LLM at source. LLM invoked only on explicit query.
"""

import os
import json
import urllib.request
import urllib.error
from ain_state_compiler.ingest.indexer import ContextIndexer


def _find_state_dir(project_dir=None):
    """Resolves the compiled_state/ directory from project root."""
    if project_dir is None:
        candidate = os.path.dirname(os.path.abspath(__file__))
        for _ in range(5):
            if os.path.isdir(os.path.join(candidate, "compiled_state")):
                return os.path.join(candidate, "compiled_state")
            candidate = os.path.dirname(candidate)
        return os.path.join(os.getcwd(), "compiled_state")
    return os.path.join(project_dir, "compiled_state")


def _expand_query(query_text: str, model="gemma3:1b") -> str:
    """SOTA Retrieval Optimization: Expands the user query using local LLM to capture synonyms and concepts."""
    prompt = (
        f"Extract key concepts, entities, and 3-4 synonyms for the following search query. "
        f"Return ONLY a space-separated string of the most important keywords, no markdown, no explanations.\n"
        f"Query: {query_text}\nKeywords:"
    )
    url = "http://localhost:11434/api/generate"
    payload = json.dumps({"model": model, "prompt": prompt, "stream": False}).encode("utf-8")
    req = urllib.request.Request(url, data=payload, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=5) as response:
            res_data = json.loads(response.read().decode("utf-8"))
            expanded = res_data.get("response", "").strip()
            # Clean up the output to ensure it's safe for FTS
            expanded = "".join(c for c in expanded if c.isalnum() or c.isspace())
            return expanded
    except Exception:
        return ""


def query_brain(query_text, project_dir=None, model="gemma3:1b"):
    """
    Query the Company Brain using SQLite FTS5 for context retrieval.
    Includes SOTA LLM-driven query expansion for maximum recall.
    """
    project_dir = project_dir or _find_state_dir()
    if os.path.basename(project_dir) == "compiled_state":
        project_dir = os.path.dirname(project_dir)

    # Attempt query expansion for SOTA retrieval
    expanded_terms = _expand_query(query_text, model)
    fts_query = f"{query_text} {expanded_terms}".strip()

    idx = ContextIndexer(project_dir)
    try:
        # FTS allows logical OR to boost recall with expanded terms
        # Convert spaces to OR to ensure broad matching across synonyms
        broad_query = " OR ".join([t for t in fts_query.split() if len(t) > 2])
        results = idx.search(broad_query, limit=5)
        
        # If broad query fails or returns too much noise, fallback to exact match
        if not results:
            results = idx.search(query_text, limit=5)
            
        if results:
            context_snippets = []
            for r in results:
                src = r.get("source", "unknown").upper()
                body = r.get("body", "")[:300]
                context_snippets.append(f"[{src}] {body}")
            selected_context = "\\n\\n".join(context_snippets)
            source_node = "FTS5 Index (LLM Expanded)" if expanded_terms else "FTS5 Index"
        else:
            selected_context = "No compiled state found or no matching events. Run `ain-brain ingest` to gather data."
            source_node = "None"
    except Exception as e:
        selected_context = f"Error querying index: {e}"
        source_node = "Error"
    finally:
        idx.close()

    # Build LLM prompt
    prompt = (
        "You are the AIN Company Brain assistant. "
        "Answer the user query using ONLY the provided compiled operational state context. "
        "If the query cannot be answered by the context, state that clearly.\\n\\n"
        f"[COMPILED CORPORATE CONTEXT]:\\n{selected_context}\\n\\n"
        f"[USER QUERY]:\\n{query_text}\\n\\nAnswer:"
    )

    # Attempt local Ollama inference
    ollama_url = "http://localhost:11434/api/generate"
    payload = json.dumps({"model": model, "prompt": prompt, "stream": False}).encode("utf-8")
    req = urllib.request.Request(
        ollama_url,
        data=payload,
        headers={"Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            res_data = json.loads(resp.read().decode("utf-8"))
            answer = res_data.get("response", "").strip()
            return answer, source_node, True
    except Exception:
        pass

    # Fallback: deterministic state resolver
    fallback = _deterministic_resolve(query_text.lower(), selected_context)
    return fallback, source_node, False


def _deterministic_resolve(query_lower, context):
    """Resolves common queries without LLM using retrieved FTS5 context."""
    if not context or "No compiled state found" in context:
         return "I cannot answer this query. No relevant context was found in the brain."
    return f"I am running offline without a local LLM. Based on my context index, here is what I found related to your query:\\n\\n{context}"
