"""
Slack Ingestor — Full History Edition
======================================
Pulls EVERY message ever posted in the workspace, including:
  - All public and private channels the bot token can access
  - All thread replies (conversations.replies for each threaded message)
  - Direct messages and group DMs (if bot has im:history scope)
  - Archived channels

Pagination: cursor-based, 1000 messages per page, resumes from checkpoint.
Rate limits: Tier 3 (50+ RPM). We use 1.2s sleep per page + exponential
             backoff on 429 responses.

Scopes required on the Slack App:
  channels:history, channels:read
  groups:history, groups:read
  im:history, mpim:history

Zero external dependencies -- stdlib urllib only.

Usage:
    from ain_state_compiler.ingest.slack_ingest import ingest_slack
    from ain_state_compiler.ingest.checkpoint import Checkpoint

    cp = Checkpoint(project_dir)
    messages = ingest_slack(
        token,
        checkpoint=cp,
        fetch_threads=True,
        full_history=False,   # True = ignore checkpoint, fetch from epoch
        progress=True,
    )
"""

import os
import json
import time
from datetime import datetime
from typing import Optional
from ain_state_compiler.ingest.mcp_stdio_client import MCPStdioClient


SLACK_API = "https://slack.com/api"
PAGE_SIZE = 1000          # max messages per page (Slack allows up to 1000)
SLEEP_BETWEEN_PAGES = 1.2   # Tier 3 rate limit: 50+ RPM
SLEEP_BETWEEN_CHANNELS = 0.5


def fetch_all_channels(mcp_client: MCPStdioClient) -> list:
    """Returns list of all channels via MCP slack_list_channels."""
    channels = []
    cursor = None
    
    while True:
        try:
            args = {"limit": 200}
            if cursor:
                args["cursor"] = cursor
            
            data = mcp_client.call_tool("slack_list_channels", args)
        except Exception as e:
            print(f"[!] MCP slack_list_channels error: {e}")
            break
            
        if not data:
            break

        # Response from MCP is usually a stringified JSON if we parse it, or raw data
        if isinstance(data, str):
            try:
                data = json.loads(data)
            except:
                break
                
        batch = data.get("channels", []) if isinstance(data, dict) else []
        if not batch:
            break
            
        channels.extend(batch)

        meta = data.get("response_metadata", {})
        cursor = meta.get("next_cursor", "")
        if not cursor:
            break
        time.sleep(SLEEP_BETWEEN_CHANNELS)

    return channels


def fetch_channel_history(
    mcp_client: MCPStdioClient,
    channel_id: str,
    channel_name: str,
    oldest: str = "0",
    checkpoint_cursor: Optional[str] = None,
) -> tuple:
    messages = []
    
    try:
        # The user requested up to 100,000 messages. We pass limit: 100000.
        # If the MCP server handles pagination internally, it will return them.
        # If it passes it raw to the Slack API, Slack might clamp it to 1000.
        data = mcp_client.call_tool("slack_get_channel_history", {
            "channel_id": channel_id,
            "limit": 100000
        })
    except Exception as e:
        print(f"[!] MCP slack_get_channel_history error for #{channel_name}: {e}")
        return messages, ""

    if isinstance(data, str):
        try:
            data = json.loads(data)
        except:
            pass

    batch = data.get("messages", []) if isinstance(data, dict) else []
    
    now = datetime.utcnow().isoformat()
    for msg in batch:
        msg["_channel_id"] = channel_id
        msg["_channel_name"] = channel_name
        msg["_ingested_at"] = now
    messages.extend(batch)

    # Return empty string for final_cursor since MCP server doesn't support pagination here
    return messages, ""


def fetch_thread_replies(
    mcp_client: MCPStdioClient,
    channel_id: str,
    channel_name: str,
    thread_ts: str,
) -> list:
    replies = []
    try:
        data = mcp_client.call_tool("slack_get_thread_replies", {
            "channel_id": channel_id,
            "thread_ts": thread_ts
        })
    except Exception as e:
        print(f"[!] MCP slack_get_thread_replies error (ts={thread_ts}): {e}")
        return replies

    if isinstance(data, str):
        try:
            data = json.loads(data)
        except:
            pass

    batch = data.get("messages", []) if isinstance(data, dict) else []
    now = datetime.utcnow().isoformat()

    # Skip index 0 on first page — that's the root message
    for msg in batch[1:]:
        msg["_channel_id"] = channel_id
        msg["_channel_name"] = channel_name
        msg["_thread_ts"] = thread_ts
        msg["_is_reply"] = True
        msg["_ingested_at"] = now
        replies.append(msg)

    return replies


def ingest_slack(
    token: str,
    team_id: str = "",
    since_ts: str = "0",
    fetch_threads: bool = True,
    checkpoint=None,
    full_history: bool = False,
    progress: bool = True,
) -> list:
    if progress:
        print("[*] Slack ingest: starting official Slack MCP server...")

    env = os.environ.copy()
    env["SLACK_BOT_TOKEN"] = token
    if team_id:
        env["SLACK_TEAM_ID"] = team_id

    npx_cmd = "npx.cmd" if os.name == "nt" else "npx"
    mcp_client = MCPStdioClient([npx_cmd, "-y", "@modelcontextprotocol/server-slack"], env=env)

    try:
        if progress:
            print("[*] Slack ingest: listing all accessible channels...")
        channels = fetch_all_channels(mcp_client)
        if progress:
            print(f"[+] Found {len(channels)} channels.")

        all_messages = []
        threaded_msgs = []

        for idx, ch in enumerate(channels, 1):
            ch_id = ch.get("id", "")
            ch_name = ch.get("name") or ch.get("user") or ch_id

            if progress:
                print(f"  [{idx}/{len(channels)}] #{ch_name}: fetching history via MCP...")

            msgs, final_cursor = fetch_channel_history(
                mcp_client, ch_id, ch_name
            )

            for m in msgs:
                if m.get("reply_count", 0) > 0:
                    threaded_msgs.append((ch_id, ch_name, m.get("ts", "")))

            all_messages.extend(msgs)
            if progress:
                print(f"    -> #{ch_name}: {len(msgs):,} messages")

            time.sleep(SLEEP_BETWEEN_CHANNELS)

        if fetch_threads and threaded_msgs:
            if progress:
                print(f"\n[*] Fetching thread replies for {len(threaded_msgs):,} threaded messages...")
            total_replies = 0
            for t_idx, (ch_id, ch_name, thread_ts) in enumerate(threaded_msgs, 1):
                if t_idx % 50 == 0 and progress:
                    print(f"    Threads: {t_idx}/{len(threaded_msgs):,} processed, {total_replies:,} replies collected...")
                replies = fetch_thread_replies(mcp_client, ch_id, ch_name, thread_ts)
                all_messages.extend(replies)
                total_replies += len(replies)
                time.sleep(0.5)
            if progress:
                print(f"[+] Thread replies: {total_replies:,} collected from {len(threaded_msgs):,} threads.")

        if progress:
            print(f"[+] Slack ingest complete. Total: {len(all_messages):,} messages (channels + threads)")

        return all_messages
    finally:
        mcp_client.close()
