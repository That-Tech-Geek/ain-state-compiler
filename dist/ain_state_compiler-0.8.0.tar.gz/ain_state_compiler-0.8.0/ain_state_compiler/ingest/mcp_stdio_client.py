import subprocess
import json
import threading
import uuid
import queue
import time

class MCPStdioClient:
    def __init__(self, command, env=None):
        self.process = subprocess.Popen(
            command,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            env=env
        )
        self.responses = {}
        self.lock = threading.Lock()
        
        self.reader_thread = threading.Thread(target=self._read_stdout, daemon=True)
        self.reader_thread.start()
        
        # Initialize MCP Server
        self._initialize()

    def _read_stdout(self):
        for line in self.process.stdout:
            if not line.strip():
                continue
            try:
                data = json.loads(line.strip())
                if "id" in data:
                    with self.lock:
                        if data["id"] in self.responses:
                            self.responses[data["id"]].put(data)
            except json.JSONDecodeError:
                # Some servers might output plain text logs to stdout (though they shouldn't)
                pass

    def _send_request(self, method, params=None):
        req_id = str(uuid.uuid4())
        q = queue.Queue()
        with self.lock:
            self.responses[req_id] = q
            
        payload = {
            "jsonrpc": "2.0",
            "id": req_id,
            "method": method,
        }
        if params is not None:
            payload["params"] = params
            
        self.process.stdin.write(json.dumps(payload) + "\n")
        self.process.stdin.flush()
        
        # Wait for response
        res = q.get(timeout=60)
        with self.lock:
            del self.responses[req_id]
            
        if "error" in res:
            raise Exception(f"MCP Error ({method}): {res['error']}")
        return res.get("result", {})

    def _send_notification(self, method, params=None):
        payload = {
            "jsonrpc": "2.0",
            "method": method,
        }
        if params is not None:
            payload["params"] = params
        self.process.stdin.write(json.dumps(payload) + "\n")
        self.process.stdin.flush()

    def _initialize(self):
        # 1. Send initialize request
        result = self._send_request("initialize", {
            "protocolVersion": "2024-11-05",
            "capabilities": {},
            "clientInfo": {
                "name": "ain-state-compiler",
                "version": "1.0.0"
            }
        })
        # 2. Send initialized notification
        self._send_notification("notifications/initialized")
        return result

    def list_tools(self):
        return self._send_request("tools/list")

    def call_tool(self, name, args):
        result = self._send_request("tools/call", {
            "name": name,
            "arguments": args
        })
        
        # Parse the standard MCP content array
        if result.get("isError"):
            raise Exception(f"Tool {name} returned error: {result}")
            
        content = result.get("content", [])
        if not content:
            return None
            
        text = content[0].get("text", "")
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            return text

    def close(self):
        if self.process:
            self.process.terminate()
            self.process.wait()
