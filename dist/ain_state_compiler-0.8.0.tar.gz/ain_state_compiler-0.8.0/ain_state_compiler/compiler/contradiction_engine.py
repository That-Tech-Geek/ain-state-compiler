"""
Contradiction Engine Module
Implements TF-IDF Similarity Matrix for the node index.
Finds conflicting statements and prompts the user to interactively resolve them.
"""

import sys
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

class ContradictionEngine:
    def __init__(self, threshold=0.85):
        self.threshold = threshold
        self.vectorizer = TfidfVectorizer(stop_words='english')

    def detect_and_resolve(self, nodes):
        """
        Takes a list of node dictionaries.
        Each node must have an 'id' and 'text' field.
        Prompts the user interactively when highly similar/conflicting nodes are detected.
        Returns a list of resolved (kept) nodes.
        """
        if not nodes or len(nodes) < 2:
            return nodes

        texts = [node.get('text', '') for node in nodes]
        ids = [node.get('id', '') for node in nodes]
        
        try:
            tfidf_matrix = self.vectorizer.fit_transform(texts)
            similarity_matrix = cosine_similarity(tfidf_matrix)
        except Exception as e:
            print(f"[!] TF-IDF generation failed: {e}")
            return nodes

        n = len(nodes)
        discarded_indices = set()

        for i in range(n):
            if i in discarded_indices:
                continue
            for j in range(i + 1, n):
                if j in discarded_indices:
                    continue
                
                sim = similarity_matrix[i, j]
                if sim >= self.threshold:
                    # We have a potential contradiction / high similarity conflict
                    print("\n" + "="*60)
                    print("⚠️  CONTRADICTION DETECTED ⚠️")
                    print("="*60)
                    print(f"Similarity Score: {sim:.2f}")
                    print(f"\n[Option 1] Source: {nodes[i].get('source', 'Unknown')} | ID: {ids[i]}")
                    print(f"Assertion: {texts[i][:200]}...")
                    print(f"\n[Option 2] Source: {nodes[j].get('source', 'Unknown')} | ID: {ids[j]}")
                    print(f"Assertion: {texts[j][:200]}...")
                    print("-" * 60)
                    
                    choice = ""
                    while choice not in ['1', '2', 'skip']:
                        try:
                            choice = input("Which one is correct? (1 / 2) or type 'skip' to keep both: ").strip().lower()
                        except (EOFError, KeyboardInterrupt):
                            print("\n[!] Conflict resolution aborted. Keeping both.")
                            choice = 'skip'
                    
                    if choice == '1':
                        print("[*] Option 1 saved as the truth. Option 2 discarded.")
                        discarded_indices.add(j)
                    elif choice == '2':
                        print("[*] Option 2 saved as the truth. Option 1 discarded.")
                        discarded_indices.add(i)
                        break # Node i is discarded, no need to check further against it
                    else:
                        print("[*] Skipped. Both kept in the compiled state.")

        resolved_nodes = [nodes[i] for i in range(n) if i not in discarded_indices]
        print(f"\n[*] Contradiction Engine finished. Resolved {len(discarded_indices)} conflicts.")
        return resolved_nodes
