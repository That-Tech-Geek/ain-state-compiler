"""
Conflict Detector Module
Programmatic, Zero-LLM contradiction detection engine.
Parses Slack, Jira, and email assertions to surface cross-departmental
state mismatches in real-time.
"""

import re


class ConflictDetector:
    """
    Detects cross-source contradictions in corporate event streams.

    Layer 3 of the AIN State Compiler moat.
    Operates 100% offline -- no LLM, no network, no external dependency.
    """

    # Patterns that indicate a feature/rollout is DISABLED
    FLAG_DISABLED_PATTERNS = [
        r"disab\w+\s+(?:the\s+)?feature\s+flag",
        r"feature\s+flag\s+\w+\s*[=:]\s*(?:FALSE|false|0|off)",
        r"flag.*set.*false",
        r"rollout.*paused",
        r"rolled?\s+back",
        r"keep.*flag.*false",
        r"do not re-enable",
        r"toggling.*off",
    ]

    # Patterns that indicate marketing / outbound GA claim
    GA_PATTERNS = [
        r"general\s+availability",
        r"\bga\b.*announce",
        r"announce.*(?:live|launched|available)",
        r"now\s+live",
        r"available\s+to\s+all",
        r"thrilled\s+to\s+announce",
    ]

    # Patterns indicating a VP/override approval
    OVERRIDE_PATTERNS = [
        r"approved\s+override",
        r"\boverride\b.*approved",
        r"authorized.*discount",
        r"discount.*authorized",
        r"bypass.*cap",
        r"exception.*approved",
        r"\d+%\s+discount",
    ]

    # Patterns indicating billing/pricing is NOT yet configured
    BILLING_PENDING_PATTERNS = [
        r"to\s+do",
        r"pending.*approval",
        r"pending.*setup",
        r"standard.*tier",
        r"standard.*invoice",
        r"not\s+(?:yet\s+)?configured",
    ]

    @classmethod
    def _text_matches(cls, text, patterns):
        """Returns True if any pattern matches the given text (case-insensitive)."""
        text_lower = text.lower()
        return any(re.search(pat, text_lower) for pat in patterns)

    @classmethod
    def _ollama_detect_conflicts(cls, all_events):
        """SOTA Contradiction Engine: Uses local Ollama to find semantic anomalies."""
        import json
        import urllib.request
        
        if not all_events:
            return []
            
        context_snippets = []
        for e in all_events[:100]: # Send top 100 recent events
            try:
                orig = json.loads(e.get("raw_json", "{}"))
                src = e.get("source", "unknown").upper()
                body = str(orig)[:300] # Trim to save context window
                context_snippets.append(f"[{src}] {body}")
            except Exception:
                pass
                
        context_text = "\n".join(context_snippets)
        prompt = (
            "You are an AI conflict detection engine. Analyze the following corporate event stream and identify ANY discrepancies, contradictions, or anomalies between different sources (e.g. Sales promised X on Slack, but Billing says Y in Jira. Or Engineering rolled back a feature, but Marketing sent an email saying it is live).\n\n"
            f"EVENT STREAM:\n{context_text}\n\n"
            "Return ONLY a raw JSON array of conflicts. No markdown, no conversational text. "
            "Format: [{\"id\": \"CON-001\", \"category\": \"PRODUCT\", \"title\": \"...\", \"severity\": \"HIGH|CRITICAL\", \"summary\": \"...\", \"evidence\": [{\"source\": \"Slack\", \"assertion\": \"...\"}], \"resolution_action\": \"...\"}]"
            "If there are no conflicts, return []."
        )
        
        url = "http://localhost:11434/api/generate"
        payload = json.dumps({"model": "gemma3:1b", "prompt": prompt, "stream": False, "format": "json"}).encode("utf-8")
        req = urllib.request.Request(url, data=payload, headers={"Content-Type": "application/json"})
        
        try:
            with urllib.request.urlopen(req, timeout=30) as response:
                res_data = json.loads(response.read().decode("utf-8"))
                output = res_data.get("response", "").strip()
                if output.startswith("```json"):
                    output = output[7:-3]
                conflicts = json.loads(output)
                if isinstance(conflicts, list):
                    return conflicts
        except Exception as e:
            print(f"[!] Ollama SOTA conflict detection failed or offline: {e}. Falling back to deterministic engine.")
        
        return None

    @classmethod
    def detect_conflicts(cls, idx):
        """
        Analyses all event streams and returns a list of detected conflict dicts.
        Dynamically extracts conflicts based on opposing state signals using SOTA local LLM, falling back to deterministic FTS.
        """
        # 0. SOTA LLM Contradiction Engine Attempt
        all_recent = idx.get_recent_events("slack", limit=30) + idx.get_recent_events("jira", limit=30) + idx.get_recent_events("gmail", limit=30)
        sota_conflicts = cls._ollama_detect_conflicts(all_recent)
        if sota_conflicts is not None:
            return sota_conflicts
            
        conflicts = []
        
        # 1. Fetch pre-filtered data using FTS keyword matching
        slack_flag_events = idx.search("disable OR feature OR flag OR false OR paused OR rollback OR re-enable", source="slack", limit=200)
        email_ga_events = idx.search("ga OR announce OR live OR availability OR thrilled", source="gmail", limit=200)
        jira_events_raw = idx.get_recent_events("jira", limit=1000) # Jira statuses need to be checked globally
        
        slack_override_events = idx.search("override OR discount OR exception", source="slack", limit=200)
        jira_billing_events = idx.search("billing OR pending OR setup OR standard OR invoice", source="jira", limit=200)
        email_complaint_events = idx.search("discrepancy OR discount", source="gmail", limit=200)

        # Parse raw json to get original formats
        import json
        slack_texts = [(e.get("channel", "Slack"), e.get("body", "")) for e in slack_flag_events + slack_override_events]
        email_texts = [(e.get("author", "Email"), e.get("subject", "") + " " + e.get("body", "")) for e in email_ga_events + email_complaint_events]
        
        jira_texts = []
        jira_statuses = {}
        for r in jira_events_raw + jira_billing_events:
            try:
                orig = json.loads(r["raw_json"])
                jid = orig.get("id", "Jira")
                jtitle = orig.get("title", "")
                jdesc = orig.get("description", "")
                jira_texts.append((jid, jtitle + " " + jdesc))
                jira_statuses[jid] = orig.get("status", "").lower()
            except Exception:
                pass

        # ----------------------------------------------------------------
        # Dynamic Detection: Feature Flags vs Marketing Claims
        # ----------------------------------------------------------------
        flag_disabled_evidence = [
            (src, t) for src, t in slack_texts if cls._text_matches(t, cls.FLAG_DISABLED_PATTERNS)
        ]
        ga_evidence = [
            (src, t) for src, t in email_texts if cls._text_matches(t, cls.GA_PATTERNS)
        ]
        
        # Look for Jira issues marked done but flags disabled
        jira_done_evidence = [
            (src, t) for src, t in jira_texts if jira_statuses.get(src) == "done"
            and any(kw in t.lower() for kw in ["analytics", "feature", "deployment", "rollout"])
        ]

        if flag_disabled_evidence and (ga_evidence or jira_done_evidence):
            evidence = []
            if jira_done_evidence:
                evidence.append({
                    "source": f"Jira ({jira_done_evidence[0][0]})",
                    "assertion": f"Issue marked DONE implying live deployment: '{jira_done_evidence[0][1][:100]}...'"
                })
            if ga_evidence:
                evidence.append({
                    "source": f"Email ({ga_evidence[0][0]})",
                    "assertion": f"Outbound GA announcement detected: '{ga_evidence[0][1][:100]}...'"
                })
            evidence.append({
                "source": f"Slack (#{flag_disabled_evidence[0][0]})",
                "assertion": f"Feature flag rollback/disable detected: '{flag_disabled_evidence[0][1][:100]}...'"
            })

            conflicts.append({
                "id": f"CON-PRD-{len(conflicts)+1:03d}",
                "category": "PRODUCT",
                "title": "Deployment Status vs Marketing/Engineering Discrepancy",
                "severity": "CRITICAL",
                "summary": "Engineering or SRE disabled a feature flag, but marketing announced it or Jira tracks it as fully done.",
                "evidence": evidence,
                "resolution_action": "Halt marketing, sync with SRE on flag status, and update Jira to BLOCKED if rolled back."
            })

        # ----------------------------------------------------------------
        # Dynamic Detection: Sales Overrides vs Billing
        # ----------------------------------------------------------------
        override_slack = [(src, t) for src, t in slack_texts if cls._text_matches(t, cls.OVERRIDE_PATTERNS)]
        billing_pending_jira = [
            (src, t) for src, t in jira_texts if cls._text_matches(t, cls.BILLING_PENDING_PATTERNS)
            and "billing" in t.lower()
        ]
        customer_complaint_email = [
            (src, t) for src, t in email_texts if "discrepancy" in t.lower() or "discount" in t.lower()
        ]

        if override_slack and billing_pending_jira:
            evidence = []
            evidence.append({
                "source": f"Slack (#{override_slack[0][0]})",
                "assertion": f"Discount/Pricing override authorized: '{override_slack[0][1][:100]}...'"
            })
            evidence.append({
                "source": f"Jira ({billing_pending_jira[0][0]})",
                "assertion": f"Billing task pending setup or at standard tier: '{billing_pending_jira[0][1][:100]}...'"
            })
            if customer_complaint_email:
                evidence.append({
                    "source": f"Email ({customer_complaint_email[0][0]})",
                    "assertion": f"Customer escalation regarding invoice discrepancy: '{customer_complaint_email[0][1][:100]}...'"
                })

            conflicts.append({
                "id": f"CON-BIL-{len(conflicts)+1:03d}",
                "category": "BILLING",
                "title": "Sales Override vs Billing System Configuration Lag",
                "severity": "HIGH",
                "summary": "A pricing override or discount was authorized verbally/on Slack, but the billing system is pending configuration.",
                "evidence": evidence,
                "resolution_action": "Update billing system to reflect the authorized override and notify the customer of the correction."
            })

        return conflicts
