# AIN State Compiler 🧠

Welcome to the **AIN State Compiler**! 

Imagine if your entire company had a single, giant brain that remembered everything anyone ever said on Slack, wrote in Jira, or sent in an email. That's what this tool does!

## 🧒 Explain Like I'm 5 (ELI5)

Think of the AIN State Compiler like a super smart librarian that works for you:

1. **Reading the Books (Ingestion):** Every day, the librarian reads all the sticky notes, letters, and to-do lists from everyone in your company (Slack, Gmail, Jira).
2. **Finding Arguments (Contradiction Engine):** Sometimes, Alice says "The sky is green" on Slack, but Bob says "The sky is blue" in Jira. The librarian is very smart. It uses math (TF-IDF Similarity) to realize Alice and Bob are arguing about the same thing!
3. **Asking You to Be the Boss (Interactive Resolution):** The librarian pauses and asks *you*: "Hey Boss! Alice says green, Bob says blue. Which one is right?" You pick the correct answer.
4. **Keeping the Truth (Knowledge Graph):** The librarian throws away the wrong answer and keeps the right one. It then organizes all the truths into an incredibly neat map (Map of Contents) so it can find any answer in 1 second later!

## 🚀 How to Install and Run

It is so easy to set up that anyone can do it!

### 1. Install the Library
Open your terminal (command prompt) and type this:
```bash
pip install ain-state-compiler
```

### 2. Setup your Brain
Type this to connect your Slack, Jira, and Gmail:
```bash
ain-brain setup
```
Just follow the on-screen instructions! 

### 3. Sync and Find Contradictions!
To start the librarian and let it find arguments:
```bash
ain-brain sync
```
*When it finds a contradiction, it will pause on the screen and ask you to choose the winner by typing `1` or `2`!*

### 4. Ask a Question
Once the brain is compiled with the truth, ask it anything:
```bash
ain-brain query "What is the status of the new billing system?"
```

## 🛠️ For the Grown-ups (Technical Details)
- **Contradiction Engine:** Uses TF-IDF cosine similarity to match vector embeddings of ingested nodes in real-time during compilation. Thresholds are customizable.
- **Interactive Resolution:** The pipeline pauses execution when cosine similarity > 0.85 between any two text nodes, enforcing deterministic state resolution by the user before committing to the state graph.
- **Knowledge Graph:** Compiles resolved nodes into an exact inverted tag index, a vector snapshot, and modular hub MOCs (`INDEX.md`), fully preparing the data for 3D visualizers (`visualizer_data.json`).

---

**Author:** Sambit Mishra  
**Contact:** sambit1912@gmail.com  
